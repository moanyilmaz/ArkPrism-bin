export class EntryAbility {
  onCreate() {}
}
