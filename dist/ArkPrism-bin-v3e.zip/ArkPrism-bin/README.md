# ArkPrism 二进制隐私API分析工具 - 部署与验证指南

## 1. 项目概述

ArkPrism 是一个面向 HarmonyOS 应用（.abc 字节码 + .so 原生库）的静态隐私敏感 API 分析工具。本包为**可直接运行的二进制包**，无需编译即可使用。

**核心算法**: CAIR (Conflict-Aware Identity Resolution) v3e  
**版本**: commit b0ee177  
**评估结果**: 8-HAP基准 P=99.0% R=96.3% F1=97.6%

## 2. 目录结构

```
ArkPrism-bin/
├── README.md                    # 本文档
├── run.bat                      # Windows 启动脚本
├── run.sh                       # Linux/macOS 启动脚本
├── config/
│   ├── privacy_apis.json        # ArkTS 隐私API规则（64包，826条）
│   ├── native_privacy_apis.json # Native C API规则（70条）
│   └── profile_combinations.json # 多源协作规则
├── lib/
│   ├── arkprism-main.jar        # 主程序（CAIR v3e）
│   ├── hisec-enhance-app-analyzer-all-in-one-26.0.0.21.jar  # HiAnalyzer 引擎
│   ├── hisec-enhance-app-analyzer-25.0.1.52.jar
│   ├── hisec-multi-language-25.0.1.71.jar
│   ├── jackson-*.jar            # JSON 序列化
│   └── slf4j-*.jar              # 日志框架
├── python_tools/
│   └── pure_angr_scanner.py     # Native SO 扫描器（基于 angr）
├── input-8hap/                  # 8个HAP测试样本（含预期结果）
│   ├── C5765880207855243995_1.5.41/
│   ├── C6917596277126662423_1.0.0/
│   ├── C6917601515137710787_1.0.0/
│   ├── C6917602215994202990_1.0.0/
│   ├── C6917602221479724885_1.0.0/
│   ├── FlameChase/
│   ├── STUFFS_NEXT-master/
│   └── legado-Harmony-main/
└── evaluation/                  # 评估报告与预期结果
    ├── eval_8hap_report.md      # 英文详细报告
    ├── eval_8hap_summary_cn.md  # 中文评估摘要
    ├── batch_summary.json       # 批量运行汇总
    └── reports/                 # 每个HAP的隐私检测报告
        ├── C5765880207855243995_1.5.41/
        │   └── *_privacy_report.json
        └── ...
```

## 3. 环境要求

| 组件 | 版本要求 | 用途 | 必须？ |
|------|----------|------|--------|
| JDK | 21+ | 运行主程序 | **是** |
| WSL2 + Python + angr | 见下方 | Native SO 分析 | 否（仅ArkTS分析不需要） |

> **说明**: 如果只需要分析 .abc 字节码（ArkTS隐私API），只需安装 JDK 21+ 即可。

## 4. 快速开始（验证流程）

### 4.1 安装 Java 21

**Windows**:
```cmd
# 下载安装 Microsoft JDK 21 或 Adoptium JDK 21
# 安装后验证：
java -version
# 应显示 openjdk version "21.x.x"
```

**Linux**:
```bash
sudo apt install openjdk-21-jdk
java -version
```

### 4.2 运行8-HAP测试

```cmd
cd ArkPrism-bin

:: 使用8-HAP测试样本运行
run.bat input-8hap
```

运行完成后，输出目录 `out/` 下会生成：

```
out/
└── batch_YYYYMMDD_HHMMSS/
    ├── C5765880207855243995_1.5.41/
    │   └── *_privacy_report.json
    ├── ...（8个HAP的报告）
    ├── arkprism_YYYYMMDD_HHMMSS.log
    └── batch_summary.json
```

### 4.3 对比验证

将新运行的结果与 `evaluation/reports/` 中的预期结果对比：

```bash
# 对比每个HAP的检测结果数量
python -c "
import json, os

for proj in ['C5765880207855243995_1.5.41', 'C6917596277126662423_1.0.0',
             'C6917601515137710787_1.0.0', 'C6917602215994202990_1.0.0',
             'C6917602221479724885_1.0.0', 'FlameChase',
             'STUFFS_NEXT-master', 'legado-Harmony-main']:
    # 读取预期结果
    ref_path = f'evaluation/reports/{proj}/{proj}_privacy_report.json'
    with open(ref_path, encoding='utf-8') as f:
        ref = json.load(f)
    ref_count = len(ref.get('privacyApiUsages', []))
    
    # 读取新结果（需要更新路径为实际输出路径）
    # new_path = f'out/batch_YYYYMMDD_HHMMSS/{proj}/{proj}_privacy_report.json'
    # with open(new_path, encoding='utf-8') as f:
    #     new = json.load(f)
    # new_count = len(new.get('privacyApiUsages', []))
    
    print(f'{proj}: 预期 {ref_count} 个API使用')
"
```

**预期结果**:

| # | 项目 | 预期API检测数 |
|---|------|--------------|
| 1 | C5765880207855243995_1.5.41 | 4 |
| 2 | C6917596277126662423_1.0.0 | 82 |
| 3 | C6917601515137710787_1.0.0 | 2 |
| 4 | C6917602215994202990_1.0.0 | 55 |
| 5 | C6917602221479724885_1.0.0 | 56 |
| 6 | FlameChase | 3 |
| 7 | STUFFS_NEXT-master | 42 |
| 8 | legado-Harmony-main | 54 |

**总计**: 298 个隐私API检测

### 4.4 验证报告格式

每个 `*_privacy_report.json` 包含以下关键信息：

```json
{
  "schemaVersion": "1.0",
  "analysisMode": "binary",
  "projectName": "...",
  "privacyApiUsages": [{
    "sourceLayer": "ArkTS",
    "apiPackage": "@kit.NetworkKit",
    "namespace": "connection",
    "method": "getDefaultNetSync",
    "dataDirection": "source",
    "profilingCategory": "network.connectivity",
    "code": "v5 = VirtualCall: v0.<getDefaultNetSync>()",
    "declaringMethod": "func_main_0",
    "permission": "ohos.permission.GET_NETWORK_INFO"
  }],
  "callChains": [...],
  "multiSourceCollaborations": [...],
  "sourceSnippets": [...]
}
```

## 5. 分析自定义HAP

### 5.1 准备输入

将 HAP 解包后的目录放入 `input/` 或指定目录：

```bash
# HAP 解包（.hap 文件本质是 zip 包）
mkdir -p MyApp_1.0.0
unzip app.hap -d MyApp_1.0.0
```

解包后的目录应包含：
```
MyApp_1.0.0/
├── ets/modules.abc     # ArkTS 字节码（必须）
├── libs/arm64-v8a/*.so # Native 库（可选）
└── module.json
```

### 5.2 运行分析

```cmd
:: 批量模式（分析指定目录下所有HAP）
run.bat C:\path\to\hap_directory

:: 单应用模式
run.bat C:\path\to\single_hap
```

### 5.3 JVM 内存配置

根据分析规模调整内存：

| 规模 | HAP数量 | JVM参数 |
|------|---------|---------|
| 小 | <10 | `-Xms4g -Xmx8g -Xss512m` |
| 中 | 10-50 | `-Xms8g -Xmx16g -Xss512m` |
| 大 | 50+ | `-Xms16g -Xmx32g -Xss512m` |

编辑 `run.bat` 中的 `java -Xms4g -Xmx8g` 进行调整。

## 6. 评估结果详情

### 6.1 整体指标

| 指标 | 数值 |
|------|------|
| 精确率 (Precision) | 99.0% (285/288) |
| 召回率 (Recall) | 96.3% (285/296) |
| F1 分数 | 97.6% |

### 6.2 各项目详情

| # | 项目 | 工具检测 | GT | TP | FP | FN | P | R |
|---|------|---------|-----|----|----|-----|---|---|
| 1 | C5765880 (打印机) | 4 | 5 | 4 | 0 | 1 | 100% | 80% |
| 2 | C6917596 (综合app) | 78 | 78 | 78 | 0 | 0 | 100% | 100% |
| 3 | C6917601 (传感器) | 2 | 2 | 2 | 0 | 0 | 100% | 100% |
| 4 | C6917602 (UniApp) | 52 | 52 | 52 | 0 | 0 | 100% | 100% |
| 5 | C6917602221 (UniApp) | 55 | 55 | 55 | 0 | 0 | 100% | 100% |
| 6 | FlameChase (开源) | 3 | 3 | 3 | 0 | 0 | 100% | 100% |
| 7 | STUFFS_NEXT (开源) | 40 | 46 | 40 | 0 | 6 | 100% | 87% |
| 8 | legado (开源) | 54 | 55 | 51 | 3 | 4 | 94.4% | 92.7% |

### 6.3 FN/FP 根因

**漏检 (FN=11)**:
- sensor.on/off 字节码合并 (9个): .abc编译器将不同传感器类型的调用合并为相同IR指令
- display.getDefaultDisplaySync 编译优化合并 (2个): 多个UI组件调用在IR中合并

**误检 (FP=3)**:
- CAIR 冲突解析过度匹配 (2个): 歧义接收者解析错误
- 重复调用点计数 (1个): IR中同一回调的重复指令

## 7. Native SO 分析（可选）

如需分析 .so 文件中的 Native API，需安装 WSL2 + angr：

```bash
# Windows: 启用 WSL
wsl --install -d Ubuntu-22.04

# WSL 内安装 angr
pip3 install angr-9.2.124rc0+h1

# 部署扫描脚本
mkdir -p ~/arkprism
cp python_tools/pure_angr_scanner.py ~/arkprism/
```

设置环境变量后运行：
```cmd
set ARKPRISM_NATIVE_MODE=wsl
run.bat input-8hap
```

## 8. 配置文件说明

### privacy_apis.json

包含 64 个系统包、826 条隐私API规则。覆盖的隐私类别：

| 类别 | 示例API |
|------|---------|
| 设备标识 | deviceInfo.brand, identifier.getOAID, deviceInfo.udid |
| 位置信息 | geoLocationManager.getCurrentLocation, getLastLocation |
| 网络连接 | connection.getDefaultNet, HttpRequest.requestInStream |
| 传感器 | sensor.on, sensor.off |
| 剪贴板 | pasteboard.getSystemPasteboard, SystemPasteboard.getData |
| 联系人 | contact.selectContacts, contact.addContact |
| 相机 | camera.getCameraManager, camera.getSupportedCameras |
| 音频 | audio.getAudioManager, audio.createAudioCapturer |
| 蓝牙 | access.getState, access.enableBluetooth |
| WiFi | wifiManager.getLinkedInfo, wifiManager.getScanInfoList |
| 短信 | sms.hasSmsCapability, sms.getDefaultSmsSimId |
| 认证 | userAuth.getUserAuthInstance, userAuth.getAvailableStatus |
| 资产存储 | asset.query |
| 日历 | Calendar.getConfig |
| 多媒体 | PhotoAccessHelper.createAsset |

### 修改规则

直接编辑 `config/privacy_apis.json` 即可添加或修改规则，无需重新编译。

## 9. 常见问题

### Q: OutOfMemoryError
增大JVM堆内存：编辑 `run.bat`，将 `-Xmx8g` 改为 `-Xmx16g` 或更大。

### Q: 找不到 .abc 文件
确保输入目录下每个HAP子目录中有 `ets/modules.abc` 文件。如未解包HAP：
```bash
unzip app.hap -d app_directory
```

### Q: Native SO 扫描失败
检查 WSL 和 angr 是否正常安装。如果不需要 Native 分析，可以忽略此错误。

### Q: IFDS NullPointerException
这是 HiAnalyzer 引擎的已知问题，不影响 API 检测结果。ArkTS API 识别和调用链构建不受影响。

### Q: 如何验证工具版本
运行后在日志文件（`out/batch_*/arkprism_*.log`）中查看 CAIR 版本信息。

## 10. Linux 运行

```bash
chmod +x run.sh
./run.sh input-8hap
```

如需 Native 分析（Linux 下不需要 WSL）：
```bash
export ARKPRISM_NATIVE_MODE=native
export ARKPRISM_WSL_SCANNER=~/arkprism/pure_angr_scanner.py
./run.sh input-8hap
```
