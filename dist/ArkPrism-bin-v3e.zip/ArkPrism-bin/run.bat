@echo off
REM ArkPrism - HarmonyOS Privacy API Analyzer
REM
REM Usage:
REM   run.bat                     - Run with default input/ directory (batch mode)
REM   run.bat <hap_dir>           - Run with a single HAP directory

setlocal enabledelayedexpansion

set "SCRIPT_DIR=%~dp0"
set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"

set "INPUT_DIR=%SCRIPT_DIR%\input"
set "OUTPUT_DIR=%SCRIPT_DIR%\out"
set "CONFIG_DIR=%SCRIPT_DIR%\config"
set "LIB_DIR=%SCRIPT_DIR%\lib"

where java >nul 2>&1
if !errorlevel! neq 0 (
    echo [ERROR] Java not found. Please install JDK 21+ and add to PATH.
    exit /b 1
)

set "CLASSPATH=%LIB_DIR%"
for %%F in ("%LIB_DIR%\*.jar") do (
    set "CLASSPATH=!CLASSPATH!;%%F"
)

if not "%~1"=="" set "INPUT_DIR=%~1"

if not exist "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"

echo ======================================================
echo ArkPrism Binary Privacy Analyzer
echo ======================================================
echo.
echo Input:     %INPUT_DIR%
echo Output:    %OUTPUT_DIR%
echo Config:    %CONFIG_DIR%
echo.

java -Xms4g -Xmx16g -Xss512m ^
    -cp "%CLASSPATH%" ^
    com.huawei.hisec.Main ^
    "%INPUT_DIR%" ^
    "%CONFIG_DIR%\privacy_apis.json" ^
    "%OUTPUT_DIR%" ^
    "%CONFIG_DIR%\profile_combinations.json" ^
    "%CONFIG_DIR%\native_privacy_apis.json"

echo.
echo Analysis complete.
pause
