# ArkPrism 使用说明

下载、输入准备、直接运行、IDEA 源码调试及 Native 环境配置方法见本目录的 `README.md`。

Windows x64 用户将应用解包目录放入 `input/`，双击 `run.bat` 即可运行。包内自带 Java 21 运行时；使用 IDEA 编译源码时需要完整 JDK 21。

结果保存在 `out/`。仅分析 ABC 无需 WSL/angr，Native SO 分析需要额外环境。
