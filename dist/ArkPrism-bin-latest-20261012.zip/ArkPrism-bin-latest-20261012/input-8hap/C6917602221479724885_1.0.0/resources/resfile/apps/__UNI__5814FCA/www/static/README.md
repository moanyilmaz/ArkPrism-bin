# 静态资源说明

## 当前图标资源

- `tabs/schedule.svg` - 今日课表
- `tabs/schedule-active.svg` - 今日课表选中态
- `tabs/attendance.svg` - 点到
- `tabs/attendance-active.svg` - 点到选中态
- `tabs/stats.svg` - 统计
- `tabs/stats-active.svg` - 统计选中态
- `tabs/class.svg` - 班级管理
- `tabs/class-active.svg` - 班级管理选中态
- `tabs/mine.svg` - 教学设置
- `tabs/mine-active.svg` - 教学设置选中态

## 注意事项
1. 所有图片建议使用 WebP 格式以优化性能
2. TabBar 图标建议使用纯色 SVG，方便主题切换
3. 新增视觉资源时应沿用课堂点到通的蓝色主主题与金色强调色
4. 不再保留旧模板的历史图标说明，新增资源应只服务当前课堂点到业务
