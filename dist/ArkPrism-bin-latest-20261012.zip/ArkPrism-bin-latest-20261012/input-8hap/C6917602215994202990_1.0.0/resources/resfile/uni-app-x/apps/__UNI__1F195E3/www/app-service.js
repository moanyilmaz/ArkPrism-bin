import "./assets/pages-json-uts.js";
import { A as App } from "./assets/App.js";
const { createSSRApp } = globalThis.Vue
import "./assets/plugin-vue-export-helper.js";
const __global__ = typeof globalThis === "undefined" ? Function("return this")() : globalThis;
__global__.__uniX = true;
function createApp() {
  const app = createSSRApp(App);
  return {
    app
  };
}
__global__.__mount__ = () => {
  createApp().app.mount("#app");
};
