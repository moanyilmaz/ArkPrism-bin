const PagesIndexIndex = () => import("./pages/index/index.js");
__definePage("pages/index/index", PagesIndexIndex);
