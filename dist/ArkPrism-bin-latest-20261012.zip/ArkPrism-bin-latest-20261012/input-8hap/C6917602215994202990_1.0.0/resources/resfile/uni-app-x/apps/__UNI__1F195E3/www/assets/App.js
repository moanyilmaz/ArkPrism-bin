const { defineComponent, onLaunch, onAppShow, onAppHide, onLastPageBackPress, onExit } = globalThis.Vue
import { _ as _export_sfc } from "./plugin-vue-export-helper.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "App",
  setup(__props) {
    let firstBackTime = 0;
    onLaunch(() => {
      uni.__f__("log", "at App.uvue:7", "App Launch");
    });
    onAppShow(() => {
      uni.__f__("log", "at App.uvue:11", "App Show");
    });
    onAppHide(() => {
      uni.__f__("log", "at App.uvue:15", "App Hide");
    });
    onLastPageBackPress(() => {
      uni.__f__("log", "at App.uvue:20", "App LastPageBackPress");
      if (firstBackTime == 0) {
        uni.showToast({
          title: "再按一次退出应用",
          position: "bottom"
        });
        firstBackTime = Date.now();
        setTimeout(() => {
          firstBackTime = 0;
        }, 2e3);
      } else if (Date.now() - firstBackTime < 2e3) {
        firstBackTime = Date.now();
        uni.exit();
      }
    });
    onExit(() => {
      uni.__f__("log", "at App.uvue:37", "App Exit");
    });
    return () => {
    };
  }
});
const _style_0 = { "uni-row": { "": { "flexDirection": "row" } }, "uni-column": { "": { "flexDirection": "column" } } };
const App = /* @__PURE__ */ _export_sfc(_sfc_main, [["styles", [_style_0]]]);
export {
  App as A
};
