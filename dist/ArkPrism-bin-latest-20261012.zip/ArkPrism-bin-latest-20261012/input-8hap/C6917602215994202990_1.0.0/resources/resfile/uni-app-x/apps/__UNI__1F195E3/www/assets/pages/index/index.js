const { defineComponent, ref, computed, onLoad, openBlock, createElementBlock, normalizeClass, unref, createElementVNode, toDisplayString, createCommentVNode, Fragment, renderList, withDirectives, isRef, vModelText, normalizeStyle } = globalThis.Vue
import { _ as _export_sfc } from "../../plugin-vue-export-helper.js";
class ElementInfo extends UTS.UTSType {
  static get$UTSMetadata$() {
    return {
      kind: 2,
      get fields() {
        return {
          key: { type: String, optional: false },
          name: { type: String, optional: false },
          desc: { type: String, optional: false },
          goodColors: { type: UTS.UTSType.withGenerics(Array, [String]), optional: false },
          avoidColors: { type: UTS.UTSType.withGenerics(Array, [String]), optional: false },
          outfitTip: { type: String, optional: false }
        };
      }
    };
  }
  constructor(options, metadata = ElementInfo.get$UTSMetadata$(), isJSONParse = false) {
    super();
    this.__props__ = UTS.UTSType.initProps(options, metadata, isJSONParse);
    this.key = this.__props__.key;
    this.name = this.__props__.name;
    this.desc = this.__props__.desc;
    this.goodColors = this.__props__.goodColors;
    this.avoidColors = this.__props__.avoidColors;
    this.outfitTip = this.__props__.outfitTip;
    delete this.__props__;
  }
}
const STORAGE_KEY = "wuxing_daily_state_v2";
const DEFAULT_MEMO = "";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  setup(__props) {
    const tabList = ref([
      new UTSJSONObject({ key: "guide", name: "今日指南" }),
      new UTSJSONObject({ key: "calendar", name: "日历统计" }),
      new UTSJSONObject({ key: "knowledge", name: "五行知识" }),
      new UTSJSONObject({ key: "settings", name: "设置" })
    ]);
    const activeTab = ref("guide");
    const elementMap = [
      new ElementInfo({ key: "wood", name: "木", desc: "木气偏旺，适合清新、舒展、有生机的穿衣风格。", goodColors: ["青色", "绿色", "浅蓝"], avoidColors: ["大面积金白", "过冷灰"], outfitTip: "上装选择青绿系，搭配米色裤装，整体轻盈自然。" }),
      new ElementInfo({ key: "fire", name: "火", desc: "火气活跃，适合明亮、热情、有气场的造型。", goodColors: ["红色", "紫色", "橙色"], avoidColors: ["深黑", "暗蓝"], outfitTip: "可用暖色内搭点亮整体，避免全身沉闷配色。" }),
      new ElementInfo({ key: "earth", name: "土", desc: "土气稳重，适合温和、平衡、质感型搭配。", goodColors: ["米黄", "卡其", "棕色"], avoidColors: ["荧光色", "高饱和撞色"], outfitTip: "建议同色系叠穿，突出沉稳和干净线条。" }),
      new ElementInfo({ key: "metal", name: "金", desc: "金气清朗，适合利落、简洁、通勤感穿搭。", goodColors: ["白色", "银灰", "奶油色"], avoidColors: ["大面积红橙", "杂乱印花"], outfitTip: "可用白灰打底，配金属饰品提升精致度。" }),
      new ElementInfo({ key: "water", name: "水", desc: "水气流动，适合深色、层次、松弛感风格。", goodColors: ["黑色", "深蓝", "雾霾蓝"], avoidColors: ["土黄", "过暖橙"], outfitTip: "深色外套配低饱和内搭，显气质也更百搭。" })
    ];
    const knowledgeList = ref([
      new UTSJSONObject({
        key: "base",
        name: "五行基础",
        lines: [
          "五行包含木、火、土、金、水，强调动态平衡。",
          "木对应生发，适合清新、舒展的视觉感受。",
          "火对应明朗，适合有亮点与热情的穿搭表达。",
          "土对应稳定，适合低饱和、质感型单品。",
          "金对应利落，适合简洁线条与清爽配色。",
          "水对应流动，适合层次与深浅过渡搭配。",
          "五行并非固定吉凶，更像每日搭配参考坐标。",
          "可优先用颜色呼应五行，再配合材质与版型。",
          "同一五行可用“主色+点缀色”避免过度堆叠。",
          "穿搭最终以舒适和场景适配为第一原则。"
        ]
      }),
      new UTSJSONObject({
        key: "color",
        name: "颜色逻辑",
        lines: [
          "推荐色可作为上装主色，形成第一视觉焦点。",
          "全身颜色控制在 2-3 种更容易显高级。",
          "高饱和色建议小面积点缀，避免喧宾夺主。",
          "同色系深浅搭配能增强层次且不易出错。",
          "中性色可作为缓冲，连接主色与点缀色。",
          "肤色偏暖可多用米色、卡其、暖棕调和。",
          "肤色偏冷可尝试灰蓝、银灰、冷白提升气质。",
          "大面积撞色需保持明度差，否则容易显乱。",
          "印花单品应搭配纯色基础款，保证整体平衡。",
          "鞋包与配饰可复用主色，提升完整度。"
        ]
      }),
      new UTSJSONObject({
        key: "scene",
        name: "场景搭配",
        lines: [
          "通勤场景建议简洁配色，突出干练与专业。",
          "约会场景可加入柔和亮色，增强亲和力。",
          "运动场景优先透气与弹性，颜色以清爽为主。",
          "聚会场景可适度提高对比度，增强存在感。",
          "出行场景建议轻便叠穿，兼顾温差与活动量。",
          "室内久坐可选择柔软面料，提升全天舒适。",
          "正式场合控制配饰数量，重点放在质感。",
          "休闲场合可用帽子或包袋做风格点睛。",
          "天气突变时外套颜色尽量与主色兼容。",
          "任何场景都建议先看天气再看风格。"
        ]
      }),
      new UTSJSONObject({
        key: "care",
        name: "实用提醒",
        lines: [
          "先确认温度、体感，再决定当日主色方向。",
          "雨天尽量避免拖地裤和吸水材质鞋面。",
          "高温天优先浅色、轻薄、透气面料。",
          "换季时可准备 1-2 件万能过渡外套。",
          "衣柜中保留基础款可显著降低搭配难度。",
          "每次新增单品前先想好 3 套可搭组合。",
          "配饰不宜过多，保留一个视觉重点即可。",
          "版型优先于流行，合身永远比跟风更重要。",
          "记录每日穿搭可快速形成个人风格库。",
          "穿搭建议仅供参考，个人状态最重要。"
        ]
      })
    ]);
    const sceneList = ref([
      new UTSJSONObject({ key: "work", name: "通勤" }),
      new UTSJSONObject({ key: "dating", name: "约会" }),
      new UTSJSONObject({ key: "sport", name: "运动" }),
      new UTSJSONObject({ key: "party", name: "聚会" }),
      new UTSJSONObject({ key: "travel", name: "出行" })
    ]);
    const weekNames = ref(["日", "一", "二", "三", "四", "五", "六"]);
    const selectedDate = ref(formatDate(/* @__PURE__ */ new Date()));
    const memoText = ref(DEFAULT_MEMO);
    const historyDates = ref([]);
    const activeKnowledgeKey = ref("base");
    const activeScene = ref("work");
    const isDarkMode = ref(false);
    const scrollTop = ref(0);
    const monthAnchor = ref(formatMonth(/* @__PURE__ */ new Date()));
    const calendarDays = ref([]);
    const monthTotalDays = ref(0);
    const monthMemoDays = ref(0);
    const monthElementCount = ref(new UTSJSONObject({}));
    const currentElement = computed(() => {
      const idx = getElementIndexByDate(selectedDate.value);
      return elementMap[idx];
    });
    const activeKnowledgeLines = computed(() => {
      for (let i = 0; i < knowledgeList.value.length; i++) {
        const item = knowledgeList.value[i];
        if (item.key == activeKnowledgeKey.value) {
          return item.lines;
        }
      }
      return [];
    });
    const monthTitle = computed(() => {
      return monthAnchor.value.replace("-", " 年 ") + " 月";
    });
    const monthElementList = computed(() => {
      var _a;
      const list = [];
      const names = new UTSJSONObject({ wood: "木", fire: "火", earth: "土", metal: "金", water: "水" });
      const keys = ["wood", "fire", "earth", "metal", "water"];
      for (let i = 0; i < keys.length; i++) {
        const k = keys[i];
        const c = (_a = monthElementCount.value[k]) !== null && _a !== void 0 ? _a : 0;
        list.push(new UTSJSONObject({ key: k, name: names[k], count: c }));
      }
      return list;
    });
    const monthTopElementLabel = computed(() => {
      var _a;
      let maxKey = "";
      let maxVal = 0;
      const keys = ["wood", "fire", "earth", "metal", "water"];
      for (let i = 0; i < keys.length; i++) {
        const k = keys[i];
        const v = (_a = monthElementCount.value[k]) !== null && _a !== void 0 ? _a : 0;
        if (v > maxVal) {
          maxVal = v;
          maxKey = k;
        }
      }
      if (maxVal == 0)
        return "-";
      if (maxKey == "wood")
        return "木";
      if (maxKey == "fire")
        return "火";
      if (maxKey == "earth")
        return "土";
      if (maxKey == "metal")
        return "金";
      return "水";
    });
    const currentSceneTip = computed(() => {
      const ek = currentElement.value.key;
      const sk = activeScene.value;
      if (sk == "work")
        return ek == "metal" ? "通勤建议干净利落，白灰同色系更专业。" : "通勤建议一主一辅两色，不要超过三种颜色。";
      if (sk == "dating")
        return ek == "fire" ? "约会可用暖色点缀，口红/包袋呼应主色。" : "约会建议柔和层次，避免过于硬朗的对比。";
      if (sk == "sport")
        return ek == "wood" ? "运动场景可选青绿系速干单品，活力更足。" : "运动建议轻便透气，配色以清爽高识别为主。";
      if (sk == "party")
        return ek == "fire" ? "聚会可适度提高饱和度，提升存在感。" : "聚会可用配饰做亮点，主装保持利落。";
      return ek == "water" ? "出行可选深色外套耐脏耐看，层次更稳定。" : "出行建议舒适优先，叠穿方便应对温差。";
    });
    onLoad(() => {
      loadLocalState();
      updateHistory(selectedDate.value);
      rebuildCalendar();
    });
    function onDateChange(e) {
      selectedDate.value = e.detail.value;
      monthAnchor.value = selectedDate.value.substring(0, 7);
      loadMemoForDate();
      updateHistory(selectedDate.value);
      rebuildCalendar();
      saveLocalState();
    }
    function toPrevDay() {
      selectedDate.value = shiftDay(selectedDate.value, -1);
      monthAnchor.value = selectedDate.value.substring(0, 7);
      loadMemoForDate();
      updateHistory(selectedDate.value);
      rebuildCalendar();
      saveLocalState();
    }
    function toNextDay() {
      selectedDate.value = shiftDay(selectedDate.value, 1);
      monthAnchor.value = selectedDate.value.substring(0, 7);
      loadMemoForDate();
      updateHistory(selectedDate.value);
      rebuildCalendar();
      saveLocalState();
    }
    function toToday() {
      selectedDate.value = formatDate(/* @__PURE__ */ new Date());
      monthAnchor.value = selectedDate.value.substring(0, 7);
      loadMemoForDate();
      updateHistory(selectedDate.value);
      rebuildCalendar();
      saveLocalState();
    }
    function switchScene(key) {
      activeScene.value = key;
      saveLocalState();
    }
    function switchKnowledge(key) {
      activeKnowledgeKey.value = key;
      saveLocalState();
    }
    function switchTab(key) {
      activeTab.value = key;
      scrollToTop();
      saveLocalState();
    }
    function clearLocalData() {
      uni.showModal(new UTSJSONObject({
        title: "确认清空？",
        content: "将清空本地保存的历史、备注与设置，且不可恢复。",
        success: (res) => {
          if (res.confirm) {
            uni.removeStorageSync(STORAGE_KEY);
            selectedDate.value = formatDate(/* @__PURE__ */ new Date());
            memoText.value = DEFAULT_MEMO;
            historyDates.value = [];
            activeKnowledgeKey.value = "base";
            activeScene.value = "work";
            isDarkMode.value = false;
            monthAnchor.value = formatMonth(/* @__PURE__ */ new Date());
            activeTab.value = "guide";
            rebuildCalendar();
            uni.showToast({ title: "已清空", icon: "success" });
          }
        }
      }));
    }
    function pickHistory(date) {
      selectedDate.value = date;
      monthAnchor.value = selectedDate.value.substring(0, 7);
      loadMemoForDate();
      updateHistory(selectedDate.value);
      rebuildCalendar();
      saveLocalState();
    }
    function openFromHistory(date) {
      pickHistory(date);
      activeTab.value = "guide";
      scrollToTop();
      saveLocalState();
      uni.showToast({ title: "已打开 " + date, icon: "none" });
    }
    function pickCalendarDate(dayObj = null) {
      selectedDate.value = dayObj.date;
      monthAnchor.value = selectedDate.value.substring(0, 7);
      loadMemoForDate();
      updateHistory(selectedDate.value);
      rebuildCalendar();
      saveLocalState();
    }
    function scrollToTop() {
      scrollTop.value = 1;
      setTimeout(() => {
        scrollTop.value = 0;
      }, 0);
    }
    function saveMemo() {
      saveLocalState();
      rebuildCalendar();
      uni.showToast({ title: "备注已保存", icon: "success" });
    }
    function toPrevMonth() {
      const dt = /* @__PURE__ */ new Date(monthAnchor.value + "-01T00:00:00");
      dt.setMonth(dt.getMonth() - 1);
      monthAnchor.value = formatMonth(dt);
      rebuildCalendar();
    }
    function toNextMonth() {
      const dt = /* @__PURE__ */ new Date(monthAnchor.value + "-01T00:00:00");
      dt.setMonth(dt.getMonth() + 1);
      monthAnchor.value = formatMonth(dt);
      rebuildCalendar();
    }
    function dayClass(dayObj = null) {
      if (dayObj.isSelected)
        return "day-cell-selected";
      if (!dayObj.inMonth)
        return "day-cell-out";
      return "";
    }
    function rebuildCalendar() {
      var _a;
      const nums = monthAnchor.value.split("-");
      const year = parseInt(nums[0]);
      parseInt(nums[1]);
      const first = /* @__PURE__ */ new Date(year + "-" + nums[1] + "-01T00:00:00");
      const firstWeek = first.getDay();
      const start = new Date(first);
      start.setDate(first.getDate() - firstWeek);
      const list = [];
      let totalDays = 0;
      let memoDays = 0;
      const elementCount = new UTSJSONObject({ wood: 0, fire: 0, earth: 0, metal: 0, water: 0 });
      const nowStr = formatDate(/* @__PURE__ */ new Date());
      const data = uni.getStorageSync(STORAGE_KEY);
      let memoMap = new UTSJSONObject({});
      if (data != null && data != "" && data.memoMap != null)
        memoMap = data.memoMap;
      for (let i = 0; i < 42; i++) {
        const dt = new Date(start);
        dt.setDate(start.getDate() + i);
        const dstr = formatDate(dt);
        const inMonth = dstr.substring(0, 7) == monthAnchor.value;
        const dayLabel = dt.getDate().toString();
        if (inMonth) {
          totalDays++;
          const hasMemo = memoMap[dstr] != null && memoMap[dstr] != "";
          if (hasMemo)
            memoDays++;
          const idx = getElementIndexByDate(dstr);
          const key = elementMap[idx].key;
          elementCount[key] = ((_a = elementCount[key]) !== null && _a !== void 0 ? _a : 0) + 1;
        }
        list.push(new UTSJSONObject({
          date: dstr,
          label: dayLabel,
          inMonth,
          isSelected: dstr == selectedDate.value,
          isToday: dstr == nowStr,
          hasMemo: memoMap[dstr] != null && memoMap[dstr] != ""
        }));
      }
      calendarDays.value = list;
      monthTotalDays.value = totalDays;
      monthMemoDays.value = memoDays;
      monthElementCount.value = elementCount;
    }
    function getElementIndexByDate(dateStr) {
      const nums = dateStr.split("-");
      const y = parseInt(nums[0]);
      const m = parseInt(nums[1]);
      const d = parseInt(nums[2]);
      const seed = y * 1e4 + m * 100 + d;
      return seed % 5;
    }
    function shiftDay(dateStr, delta) {
      const dt = /* @__PURE__ */ new Date(dateStr + "T00:00:00");
      dt.setDate(dt.getDate() + delta);
      return formatDate(dt);
    }
    function formatMonth(date) {
      const y = date.getFullYear();
      const m = (date.getMonth() + 1).toString().padStart(2, "0");
      return y + "-" + m;
    }
    function formatDate(date) {
      const y = date.getFullYear();
      const m = (date.getMonth() + 1).toString().padStart(2, "0");
      const d = date.getDate().toString().padStart(2, "0");
      return y + "-" + m + "-" + d;
    }
    function updateHistory(dateStr) {
      const filtered = [];
      filtered.push(dateStr);
      for (let i = 0; i < historyDates.value.length; i++) {
        const item = historyDates.value[i];
        if (item != dateStr)
          filtered.push(item);
        if (filtered.length >= 10)
          break;
      }
      historyDates.value = filtered;
    }
    function loadMemoForDate() {
      const data = uni.getStorageSync(STORAGE_KEY);
      if (data == null || data == "") {
        memoText.value = DEFAULT_MEMO;
        return null;
      }
      const map = data.memoMap;
      if (map != null && map[selectedDate.value] != null)
        memoText.value = map[selectedDate.value];
      else
        memoText.value = DEFAULT_MEMO;
    }
    function loadLocalState() {
      const data = uni.getStorageSync(STORAGE_KEY);
      if (data == null || data == "")
        return null;
      if (data.lastDate != null && data.lastDate != "")
        selectedDate.value = data.lastDate;
      if (data.history != null && data.history.length > 0)
        historyDates.value = data.history;
      if (data.activeKnowledge != null && data.activeKnowledge != "")
        activeKnowledgeKey.value = data.activeKnowledge;
      if (data.activeScene != null && data.activeScene != "")
        activeScene.value = data.activeScene;
      if (data.activeTab != null && data.activeTab != "")
        activeTab.value = data.activeTab;
      if (data.darkMode != null)
        isDarkMode.value = data.darkMode;
      if (data.monthAnchor != null && data.monthAnchor != "")
        monthAnchor.value = data.monthAnchor;
      else
        monthAnchor.value = selectedDate.value.substring(0, 7);
      loadMemoForDate();
    }
    function saveLocalState() {
      const oldData = uni.getStorageSync(STORAGE_KEY);
      let memoMap = new UTSJSONObject({});
      if (oldData != null && oldData != "" && oldData.memoMap != null)
        memoMap = oldData.memoMap;
      memoMap[selectedDate.value] = memoText.value;
      uni.setStorageSync(STORAGE_KEY, new UTSJSONObject({
        lastDate: selectedDate.value,
        history: historyDates.value,
        activeKnowledge: activeKnowledgeKey.value,
        activeScene: activeScene.value,
        activeTab: activeTab.value,
        darkMode: isDarkMode.value,
        monthAnchor: monthAnchor.value,
        memoMap
      }));
    }
    return (_ctx = null, _cache = null) => {
      return openBlock(), createElementBlock("view", new UTSJSONObject({
        class: normalizeClass(["page", unref(isDarkMode) ? "theme-dark" : "theme-light"])
      }), [
        createElementVNode("scroll-view", new UTSJSONObject({
          class: "content-scroll",
          "scroll-y": "true",
          "scroll-top": unref(scrollTop)
        }), [
          createElementVNode("view", new UTSJSONObject({ class: "hero" }), [
            createElementVNode("text", new UTSJSONObject({ class: "hero-title" }), "五行穿衣搭配每日指南"),
            createElementVNode("text", new UTSJSONObject({ class: "hero-subtitle" }), "离线可用 · 可选具体日期 · 本地保存")
          ]),
          unref(activeTab) == "guide" ? (openBlock(), createElementBlock("view", new UTSJSONObject({
            key: 0,
            class: "card selector-card"
          }), [
            createElementVNode("text", new UTSJSONObject({ class: "section-title" }), "选择日期"),
            createElementVNode("picker", new UTSJSONObject({
              mode: "date",
              value: unref(selectedDate),
              onChange: onDateChange
            }), [
              createElementVNode("view", new UTSJSONObject({ class: "date-picker-box" }), [
                createElementVNode("text", new UTSJSONObject({ class: "date-label" }), toDisplayString(unref(selectedDate)), 1),
                createElementVNode("text", new UTSJSONObject({ class: "date-tip" }), "点击切换具体天数")
              ])
            ], 40, ["value"]),
            createElementVNode("view", new UTSJSONObject({ class: "action-row" }), [
              createElementVNode("button", new UTSJSONObject({
                class: "big-btn ghost-btn",
                style: new UTSJSONObject({ "margin-right": "8px" }),
                onClick: toPrevDay
              }), "前一天"),
              createElementVNode("button", new UTSJSONObject({
                class: "big-btn primary-btn",
                style: new UTSJSONObject({ "margin-right": "8px" }),
                onClick: toToday
              }), "回到今天"),
              createElementVNode("button", new UTSJSONObject({
                class: "big-btn ghost-btn",
                onClick: toNextDay
              }), "后一天")
            ])
          ])) : createCommentVNode("", true),
          unref(activeTab) == "calendar" ? (openBlock(), createElementBlock("view", new UTSJSONObject({
            key: 1,
            class: "card"
          }), [
            createElementVNode("view", new UTSJSONObject({ class: "calendar-header" }), [
              createElementVNode("text", new UTSJSONObject({ class: "section-title no-margin" }), "本地穿搭日历"),
              createElementVNode("view", new UTSJSONObject({ class: "mini-action-row" }), [
                createElementVNode("text", new UTSJSONObject({
                  class: "mini-link",
                  onClick: toPrevMonth
                }), "上月"),
                createElementVNode("text", new UTSJSONObject({
                  class: "month-label",
                  style: new UTSJSONObject({ "margin-left": "10px", "margin-right": "10px" })
                }), toDisplayString(unref(monthTitle)), 1),
                createElementVNode("text", new UTSJSONObject({
                  class: "mini-link",
                  onClick: toNextMonth
                }), "下月")
              ])
            ]),
            createElementVNode("view", new UTSJSONObject({ class: "week-row" }), [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(weekNames), (w, idx) => {
                return openBlock(), createElementBlock("text", new UTSJSONObject({
                  class: "week-item",
                  key: idx
                }), toDisplayString(w), 1);
              }), 128))
            ]),
            createElementVNode("view", new UTSJSONObject({ class: "calendar-grid" }), [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(calendarDays), (dayObj = null, idx) => {
                return openBlock(), createElementBlock("view", new UTSJSONObject({
                  class: normalizeClass(["day-cell", dayClass(dayObj)]),
                  key: idx,
                  onClick: ($event = null) => {
                    return pickCalendarDate(dayObj);
                  }
                }), [
                  createElementVNode("text", new UTSJSONObject({
                    class: normalizeClass(["day-text", dayObj.isSelected ? "day-text-selected" : dayObj.inMonth ? "" : "day-text-out"])
                  }), toDisplayString(dayObj.label), 3),
                  dayObj.hasMemo ? (openBlock(), createElementBlock("view", new UTSJSONObject({
                    key: 0,
                    class: "memo-dot"
                  }))) : createCommentVNode("", true)
                ], 10, ["onClick"]);
              }), 128))
            ])
          ])) : createCommentVNode("", true),
          unref(activeTab) == "calendar" ? (openBlock(), createElementBlock("view", new UTSJSONObject({
            key: 2,
            class: "card stats-card"
          }), [
            createElementVNode("text", new UTSJSONObject({ class: "section-title" }), "本月统计"),
            createElementVNode("view", new UTSJSONObject({ class: "stats-row" }), [
              createElementVNode("view", new UTSJSONObject({ class: "stats-item" }), [
                createElementVNode("text", new UTSJSONObject({ class: "stats-number" }), toDisplayString(unref(monthMemoDays)), 1),
                createElementVNode("text", new UTSJSONObject({ class: "stats-label" }), "已记录天数")
              ]),
              createElementVNode("view", new UTSJSONObject({ class: "stats-item" }), [
                createElementVNode("text", new UTSJSONObject({ class: "stats-number" }), toDisplayString(unref(monthTotalDays)), 1),
                createElementVNode("text", new UTSJSONObject({ class: "stats-label" }), "本月总天数")
              ]),
              createElementVNode("view", new UTSJSONObject({ class: "stats-item" }), [
                createElementVNode("text", new UTSJSONObject({ class: "stats-number" }), toDisplayString(unref(monthTopElementLabel)), 1),
                createElementVNode("text", new UTSJSONObject({ class: "stats-label" }), "主导五行")
              ])
            ]),
            createElementVNode("view", new UTSJSONObject({ class: "chip-row" }), [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(monthElementList), (item = null, idx) => {
                return openBlock(), createElementBlock("view", new UTSJSONObject({
                  class: "stat-chip chip-item",
                  key: idx
                }), [
                  createElementVNode("text", new UTSJSONObject({ class: "stat-chip-name" }), toDisplayString(item.name), 1),
                  createElementVNode("text", new UTSJSONObject({ class: "stat-chip-value" }), toDisplayString(item.count) + " 天", 1)
                ]);
              }), 128))
            ])
          ])) : createCommentVNode("", true),
          unref(activeTab) == "guide" ? (openBlock(), createElementBlock("view", new UTSJSONObject({
            key: 3,
            class: "card"
          }), [
            createElementVNode("text", new UTSJSONObject({ class: "section-title" }), "场景模式"),
            createElementVNode("view", new UTSJSONObject({ class: "chip-row" }), [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(sceneList), (scene, idx) => {
                return openBlock(), createElementBlock("view", new UTSJSONObject({
                  class: normalizeClass(["scene-chip chip-item", unref(activeScene) == scene.key ? "scene-chip-active" : ""]),
                  key: idx,
                  onClick: ($event = null) => {
                    return switchScene(scene.key);
                  }
                }), [
                  createElementVNode("text", new UTSJSONObject({
                    class: normalizeClass(["scene-chip-text", unref(activeScene) == scene.key ? "scene-chip-text-active" : ""])
                  }), toDisplayString(scene.name), 3)
                ], 10, ["onClick"]);
              }), 128))
            ])
          ])) : createCommentVNode("", true),
          unref(activeTab) == "guide" ? (openBlock(), createElementBlock("view", new UTSJSONObject({
            key: 4,
            class: "card result-card"
          }), [
            createElementVNode("view", new UTSJSONObject({ class: "result-header" }), [
              createElementVNode("text", new UTSJSONObject({ class: "section-title" }), "今日主运五行"),
              createElementVNode("text", new UTSJSONObject({ class: "element-tag" }), toDisplayString(unref(currentElement).name), 1)
            ]),
            createElementVNode("text", new UTSJSONObject({ class: "result-desc" }), toDisplayString(unref(currentElement).desc), 1),
            createElementVNode("view", new UTSJSONObject({ class: "color-block" }), [
              createElementVNode("text", new UTSJSONObject({ class: "sub-title" }), "宜穿主色"),
              createElementVNode("view", new UTSJSONObject({ class: "chip-row" }), [
                (openBlock(true), createElementBlock(Fragment, null, renderList(unref(currentElement).goodColors, (color, idx) => {
                  return openBlock(), createElementBlock("text", new UTSJSONObject({
                    class: "color-chip chip-item",
                    key: idx
                  }), toDisplayString(color), 1);
                }), 128))
              ])
            ]),
            createElementVNode("view", new UTSJSONObject({ class: "color-block avoid-block" }), [
              createElementVNode("text", new UTSJSONObject({ class: "sub-title" }), "少穿颜色"),
              createElementVNode("view", new UTSJSONObject({ class: "chip-row" }), [
                (openBlock(true), createElementBlock(Fragment, null, renderList(unref(currentElement).avoidColors, (color, idx) => {
                  return openBlock(), createElementBlock("text", new UTSJSONObject({
                    class: "color-chip avoid-chip chip-item",
                    key: idx
                  }), toDisplayString(color), 1);
                }), 128))
              ])
            ]),
            createElementVNode("text", new UTSJSONObject({ class: "suggest-text" }), "基础建议：" + toDisplayString(unref(currentElement).outfitTip), 1),
            createElementVNode("text", new UTSJSONObject({ class: "suggest-text" }), "场景建议：" + toDisplayString(unref(currentSceneTip)), 1)
          ])) : createCommentVNode("", true),
          unref(activeTab) == "knowledge" ? (openBlock(), createElementBlock("view", new UTSJSONObject({
            key: 5,
            class: "card"
          }), [
            createElementVNode("text", new UTSJSONObject({ class: "section-title" }), "五行知识"),
            createElementVNode("view", new UTSJSONObject({ class: "knowledge-tabs" }), [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(knowledgeList), (item, idx) => {
                return openBlock(), createElementBlock("view", new UTSJSONObject({
                  class: normalizeClass(["knowledge-tab chip-item", unref(activeKnowledgeKey) == item.key ? "knowledge-tab-active" : ""]),
                  key: idx,
                  onClick: ($event = null) => {
                    return switchKnowledge(item.key);
                  }
                }), [
                  createElementVNode("text", new UTSJSONObject({
                    class: normalizeClass(["knowledge-tab-text", unref(activeKnowledgeKey) == item.key ? "knowledge-tab-text-active" : ""])
                  }), toDisplayString(item.name), 3)
                ], 10, ["onClick"]);
              }), 128))
            ]),
            createElementVNode("view", new UTSJSONObject({ class: "knowledge-list" }), [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(activeKnowledgeLines), (line, idx) => {
                return openBlock(), createElementBlock("view", new UTSJSONObject({
                  class: "knowledge-item",
                  key: idx
                }), [
                  createElementVNode("text", new UTSJSONObject({ class: "knowledge-index" }), toDisplayString(idx + 1) + ".", 1),
                  createElementVNode("text", new UTSJSONObject({ class: "knowledge-content" }), toDisplayString(line), 1)
                ]);
              }), 128))
            ])
          ])) : createCommentVNode("", true),
          unref(activeTab) == "guide" ? (openBlock(), createElementBlock("view", new UTSJSONObject({
            key: 6,
            class: "card"
          }), [
            createElementVNode("text", new UTSJSONObject({ class: "section-title" }), "今日备注"),
            withDirectives(createElementVNode("textarea", new UTSJSONObject({
              class: "memo-input",
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event = null) => {
                return isRef(memoText) ? memoText.value = $event : null;
              }),
              placeholder: "记录今日穿搭灵感、心情或出行场景",
              maxlength: "120"
            }), null, 512), [
              [vModelText, unref(memoText)]
            ]),
            createElementVNode("button", new UTSJSONObject({
              class: "big-btn primary-btn",
              onClick: saveMemo
            }), "保存备注")
          ])) : createCommentVNode("", true),
          unref(activeTab) == "calendar" ? (openBlock(), createElementBlock("view", new UTSJSONObject({
            key: 7,
            class: "card history-card"
          }), [
            createElementVNode("text", new UTSJSONObject({ class: "section-title" }), "最近查看"),
            unref(historyDates).length == 0 ? (openBlock(), createElementBlock("view", new UTSJSONObject({
              key: 0,
              class: "empty-tip"
            }), [
              createElementVNode("text", null, "暂无记录，先选择一个日期吧")
            ])) : (openBlock(), createElementBlock("view", new UTSJSONObject({
              key: 1,
              class: "history-list"
            }), [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(historyDates), (item, idx) => {
                return openBlock(), createElementBlock("view", new UTSJSONObject({
                  class: "history-item",
                  key: idx,
                  onClick: ($event = null) => {
                    return openFromHistory(item);
                  }
                }), [
                  createElementVNode("text", new UTSJSONObject({ class: "history-date" }), toDisplayString(item), 1),
                  createElementVNode("text", new UTSJSONObject({
                    class: "history-link",
                    onClick: ($event = null) => {
                      return openFromHistory(item);
                    }
                  }), "查看", 8, ["onClick"])
                ], 8, ["onClick"]);
              }), 128))
            ]))
          ])) : createCommentVNode("", true),
          unref(activeTab) == "settings" ? (openBlock(), createElementBlock("view", new UTSJSONObject({
            key: 8,
            class: "card"
          }), [
            createElementVNode("text", new UTSJSONObject({ class: "section-title" }), "设置"),
            createElementVNode("button", new UTSJSONObject({
              class: "big-btn ghost-btn",
              onClick: clearLocalData
            }), "清空本地数据"),
            createElementVNode("text", new UTSJSONObject({ class: "setting-hint" }), "会清空：历史、备注、场景、Tab、主题等（不可恢复）")
          ])) : createCommentVNode("", true),
          createElementVNode("view", new UTSJSONObject({ class: "content-bottom-space" }))
        ], 8, ["scroll-top"]),
        createElementVNode("view", new UTSJSONObject({ class: "bottom-tabbar" }), [
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(tabList), (t, idx) => {
            return openBlock(), createElementBlock("view", new UTSJSONObject({
              key: t.key,
              class: normalizeClass(["tab-item", unref(activeTab) == t.key ? "tab-item-active" : ""]),
              style: normalizeStyle(idx == unref(tabList).length - 1 ? "" : "margin-right: 8px;"),
              onClick: ($event = null) => {
                return switchTab(t.key);
              }
            }), [
              createElementVNode("text", new UTSJSONObject({
                class: normalizeClass(["tab-text", unref(activeTab) == t.key ? "tab-text-active" : ""])
              }), toDisplayString(t.name), 3)
            ], 14, ["onClick"]);
          }), 128))
        ])
      ], 2);
    };
  }
});
const _style_0 = { "page": { "": { "height": "100%", "position": "relative", "boxSizing": "border-box" } }, "theme-light": { "": { "backgroundColor": "#f8f5ef" } }, "theme-dark": { "": { "backgroundColor": "#1d1f22" } }, "content-scroll": { "": { "height": "100%", "paddingTop": 14, "paddingRight": 14, "paddingBottom": 14, "paddingLeft": 14, "boxSizing": "border-box" } }, "content-bottom-space": { "": { "height": 84 } }, "bottom-tabbar": { "": { "position": "absolute", "left": 14, "right": 14, "bottom": 10, "height": 56, "paddingTop": 8, "paddingRight": 8, "paddingBottom": 8, "paddingLeft": 8, "borderTopLeftRadius": 16, "borderTopRightRadius": 16, "borderBottomRightRadius": 16, "borderBottomLeftRadius": 16, "backgroundColor": "#fffdf8", "borderTopWidth": 1, "borderRightWidth": 1, "borderBottomWidth": 1, "borderLeftWidth": 1, "borderTopStyle": "solid", "borderRightStyle": "solid", "borderBottomStyle": "solid", "borderLeftStyle": "solid", "borderTopColor": "#e9dcc8", "borderRightColor": "#e9dcc8", "borderBottomColor": "#e9dcc8", "borderLeftColor": "#e9dcc8", "flexDirection": "row" }, ".theme-dark ": { "backgroundColor": "#2a2d31", "borderTopColor": "#3f454d", "borderRightColor": "#3f454d", "borderBottomColor": "#3f454d", "borderLeftColor": "#3f454d" } }, "hero": { "": { "backgroundImage": "linear-gradient(135deg, #325d4a 0%, #6d4935 100%)", "backgroundColor": "rgba(0,0,0,0)", "borderTopLeftRadius": 18, "borderTopRightRadius": 18, "borderBottomRightRadius": 18, "borderBottomLeftRadius": 18, "paddingTop": 18, "paddingRight": 18, "paddingBottom": 18, "paddingLeft": 18, "marginBottom": 12 } }, "hero-title": { "": { "fontSize": 21, "fontWeight": "700", "color": "#fff7ea" } }, "hero-subtitle": { "": { "marginTop": 8, "fontSize": 14, "color": "#f6e7d3" } }, "tab-item": { "": { "flexGrow": 1, "flexShrink": 1, "flexBasis": "0%", "height": 40, "borderTopLeftRadius": 12, "borderTopRightRadius": 12, "borderBottomRightRadius": 12, "borderBottomLeftRadius": 12, "alignItems": "center", "justifyContent": "center", "backgroundColor": "#f2e6d6", "borderTopWidth": 1, "borderRightWidth": 1, "borderBottomWidth": 1, "borderLeftWidth": 1, "borderTopStyle": "solid", "borderRightStyle": "solid", "borderBottomStyle": "solid", "borderLeftStyle": "solid", "borderTopColor": "#cfb293", "borderRightColor": "#cfb293", "borderBottomColor": "#cfb293", "borderLeftColor": "#cfb293" }, ".theme-dark ": { "backgroundColor": "#363b42", "borderTopColor": "#4a525e", "borderRightColor": "#4a525e", "borderBottomColor": "#4a525e", "borderLeftColor": "#4a525e" } }, "tab-item-active": { "": { "backgroundColor": "#1f6a50", "borderTopColor": "#1f6a50", "borderRightColor": "#1f6a50", "borderBottomColor": "#1f6a50", "borderLeftColor": "#1f6a50" } }, "tab-text": { "": { "fontSize": 13, "fontWeight": "700", "color": "#2b1f18" }, ".theme-dark ": { "color": "#f2e9dc" } }, "tab-text-active": { "": { "color": "#ffffff" } }, "setting-label": { "": { "fontSize": 15, "color": "#3e2f26", "fontWeight": "600" }, ".theme-dark ": { "color": "#f2e9dc" } }, "setting-divider": { "": { "height": 1, "backgroundColor": "#e9dcc8", "marginTop": 12, "marginBottom": 12 }, ".theme-dark ": { "backgroundColor": "#3f454d" } }, "setting-hint": { "": { "marginTop": 10, "fontSize": 12, "color": "#7a6553", "lineHeight": "18px" }, ".theme-dark ": { "color": "#c7b09a" } }, "card": { "": { "backgroundColor": "#fffdf8", "borderTopLeftRadius": 16, "borderTopRightRadius": 16, "borderBottomRightRadius": 16, "borderBottomLeftRadius": 16, "paddingTop": 14, "paddingRight": 14, "paddingBottom": 14, "paddingLeft": 14, "marginBottom": 12, "borderTopWidth": 1, "borderRightWidth": 1, "borderBottomWidth": 1, "borderLeftWidth": 1, "borderTopStyle": "solid", "borderRightStyle": "solid", "borderBottomStyle": "solid", "borderLeftStyle": "solid", "borderTopColor": "#e9dcc8", "borderRightColor": "#e9dcc8", "borderBottomColor": "#e9dcc8", "borderLeftColor": "#e9dcc8" }, ".theme-dark ": { "backgroundColor": "#2a2d31", "borderTopColor": "#3f454d", "borderRightColor": "#3f454d", "borderBottomColor": "#3f454d", "borderLeftColor": "#3f454d" } }, "section-title": { "": { "fontSize": 17, "fontWeight": "600", "color": "#3e2f26", "marginBottom": 12 }, ".theme-dark ": { "color": "#f2e9dc" } }, "no-margin": { "": { "marginBottom": 0 } }, "setting-row": { "": { "flexDirection": "row", "justifyContent": "space-between", "alignItems": "center" } }, "date-picker-box": { "": { "backgroundColor": "#f6efe4", "borderTopLeftRadius": 12, "borderTopRightRadius": 12, "borderBottomRightRadius": 12, "borderBottomLeftRadius": 12, "paddingTop": 14, "paddingRight": 14, "paddingBottom": 14, "paddingLeft": 14, "marginBottom": 12 }, ".theme-dark ": { "backgroundColor": "#363a40" } }, "date-label": { "": { "fontSize": 19, "color": "#29463a", "fontWeight": "700" }, ".theme-dark ": { "color": "#d5efe4" } }, "date-tip": { "": { "fontSize": 13, "color": "#866755", "marginTop": 5 }, ".theme-dark ": { "color": "#cab49b" } }, "action-row": { "": { "flexDirection": "row", "justifyContent": "space-between" } }, "big-btn": { "": { "flexGrow": 1, "flexShrink": 1, "flexBasis": "0%", "height": 44, "lineHeight": "44px", "borderTopLeftRadius": 12, "borderTopRightRadius": 12, "borderBottomRightRadius": 12, "borderBottomLeftRadius": 12, "fontSize": 15, "fontWeight": "600" } }, "primary-btn": { "": { "backgroundColor": "#2f6f55", "color": "#ffffff", "borderTopWidth": "medium", "borderRightWidth": "medium", "borderBottomWidth": "medium", "borderLeftWidth": "medium", "borderTopStyle": "none", "borderRightStyle": "none", "borderBottomStyle": "none", "borderLeftStyle": "none", "borderTopColor": "#000000", "borderRightColor": "#000000", "borderBottomColor": "#000000", "borderLeftColor": "#000000" } }, "ghost-btn": { "": { "backgroundColor": "#efe2d0", "color": "#5a3f30", "borderTopWidth": 1, "borderRightWidth": 1, "borderBottomWidth": 1, "borderLeftWidth": 1, "borderTopStyle": "solid", "borderRightStyle": "solid", "borderBottomStyle": "solid", "borderLeftStyle": "solid", "borderTopColor": "#d8c1a6", "borderRightColor": "#d8c1a6", "borderBottomColor": "#d8c1a6", "borderLeftColor": "#d8c1a6" }, ".theme-dark ": { "backgroundColor": "#3b3f45", "color": "#e8dccc", "borderTopColor": "#545b65", "borderRightColor": "#545b65", "borderBottomColor": "#545b65", "borderLeftColor": "#545b65" } }, "calendar-header": { "": { "flexDirection": "row", "justifyContent": "space-between", "alignItems": "center", "marginBottom": 10 } }, "mini-action-row": { "": { "flexDirection": "row", "alignItems": "center" } }, "mini-link": { "": { "fontSize": 13, "color": "#2f6f55", "fontWeight": "600" } }, "month-label": { "": { "fontSize": 13, "color": "#6b5242" }, ".theme-dark ": { "color": "#cbb49e" } }, "week-row": { "": { "flexDirection": "row", "marginBottom": 8 } }, "week-item": { "": { "width": "14.28%", "textAlign": "center", "fontSize": 12, "color": "#8a715f" }, ".theme-dark ": { "color": "#bfa892" } }, "calendar-grid": { "": { "flexDirection": "row", "flexWrap": "wrap" } }, "day-cell": { "": { "width": "14.28%", "height": 44, "alignItems": "center", "justifyContent": "center", "borderTopLeftRadius": 8, "borderTopRightRadius": 8, "borderBottomRightRadius": 8, "borderBottomLeftRadius": 8, "marginBottom": 4 } }, "day-cell-selected": { "": { "backgroundColor": "#2f6f55" } }, "day-cell-out": { "": { "backgroundColor": "rgba(0,0,0,0)" } }, "day-text": { "": { "fontSize": 13, "color": "#44362d" }, ".theme-dark ": { "color": "#e9dece" } }, "day-text-selected": { "": { "color": "#ffffff" } }, "day-text-out": { "": { "color": "#a79586" }, ".theme-dark ": { "color": "#7f8a96" } }, "memo-dot": { "": { "width": 5, "height": 5, "borderTopLeftRadius": 999, "borderTopRightRadius": 999, "borderBottomRightRadius": 999, "borderBottomLeftRadius": 999, "backgroundColor": "#ce5d4d", "marginTop": 2 } }, "stats-card": { "": { "paddingTop": 10 } }, "stats-row": { "": { "flexDirection": "row", "justifyContent": "space-between", "marginBottom": 10 } }, "stats-item": { "": { "flexGrow": 1, "flexShrink": 1, "flexBasis": "0%", "alignItems": "center" } }, "stats-number": { "": { "fontSize": 18, "fontWeight": "700", "color": "#2f6f55" }, ".theme-dark ": { "color": "#d9f0e5" } }, "stats-label": { "": { "fontSize": 12, "color": "#7a6553", "marginTop": 2 }, ".theme-dark ": { "color": "#c7b09a" } }, "stat-chip": { "": { "paddingTop": 6, "paddingRight": 10, "paddingBottom": 6, "paddingLeft": 10, "borderTopLeftRadius": 999, "borderTopRightRadius": 999, "borderBottomRightRadius": 999, "borderBottomLeftRadius": 999, "backgroundColor": "#efe6d7", "flexDirection": "row", "alignItems": "center" }, ".theme-dark ": { "backgroundColor": "#3a3f45" } }, "stat-chip-name": { "": { "fontSize": 12, "color": "#2b1f18", "marginRight": 6 }, ".theme-dark ": { "color": "#f2e4d3" } }, "stat-chip-value": { "": { "fontSize": 12, "color": "#2f6f55" }, ".theme-dark ": { "color": "#d9f0e5" } }, "chip-row": { "": { "flexDirection": "row", "flexWrap": "wrap" } }, "chip-item": { "": { "marginRight": 8, "marginBottom": 8 } }, "scene-chip": { "": { "backgroundColor": "#efe6d7", "paddingTop": 8, "paddingRight": 12, "paddingBottom": 8, "paddingLeft": 12, "borderTopLeftRadius": 10, "borderTopRightRadius": 10, "borderBottomRightRadius": 10, "borderBottomLeftRadius": 10, "borderTopWidth": 1, "borderRightWidth": 1, "borderBottomWidth": 1, "borderLeftWidth": 1, "borderTopStyle": "solid", "borderRightStyle": "solid", "borderBottomStyle": "solid", "borderLeftStyle": "solid", "borderTopColor": "#dcc4a9", "borderRightColor": "#dcc4a9", "borderBottomColor": "#dcc4a9", "borderLeftColor": "#dcc4a9" }, ".theme-dark ": { "backgroundColor": "#353a40", "borderTopColor": "#4a525e", "borderRightColor": "#4a525e", "borderBottomColor": "#4a525e", "borderLeftColor": "#4a525e" } }, "scene-chip-active": { "": { "backgroundColor": "#1f6a50", "borderTopColor": "#1f6a50", "borderRightColor": "#1f6a50", "borderBottomColor": "#1f6a50", "borderLeftColor": "#1f6a50" } }, "scene-chip-text": { "": { "fontSize": 13, "color": "#2b1f18" }, ".theme-dark ": { "color": "#f2e9dc" } }, "scene-chip-text-active": { "": { "color": "#ffffff" } }, "result-header": { "": { "flexDirection": "row", "justifyContent": "space-between", "alignItems": "center" } }, "element-tag": { "": { "backgroundColor": "#e9f1ed", "color": "#2f6f55", "paddingTop": 4, "paddingRight": 10, "paddingBottom": 4, "paddingLeft": 10, "borderTopLeftRadius": 999, "borderTopRightRadius": 999, "borderBottomRightRadius": 999, "borderBottomLeftRadius": 999, "fontSize": 14, "fontWeight": "600" }, ".theme-dark ": { "backgroundColor": "#355449", "color": "#d9f0e5" } }, "result-desc": { "": { "fontSize": 14, "color": "#5a4a3d", "lineHeight": "22px", "marginBottom": 10 }, ".theme-dark ": { "color": "#d4c7b7" } }, "sub-title": { "": { "fontSize": 14, "color": "#4e3b30", "fontWeight": "600", "marginBottom": 7 }, ".theme-dark ": { "color": "#decfbd" } }, "color-block": { "": { "backgroundColor": "#f7f2e9", "borderTopLeftRadius": 10, "borderTopRightRadius": 10, "borderBottomRightRadius": 10, "borderBottomLeftRadius": 10, "paddingTop": 10, "paddingRight": 10, "paddingBottom": 10, "paddingLeft": 10, "marginBottom": 10 }, ".theme-dark ": { "backgroundColor": "#343a3f" } }, "avoid-block": { "": { "backgroundColor": "#f8ece8" }, ".theme-dark ": { "backgroundColor": "#423538" } }, "color-chip": { "": { "backgroundColor": "#e3efe9", "color": "#1f6a50", "paddingTop": 6, "paddingRight": 10, "paddingBottom": 6, "paddingLeft": 10, "borderTopLeftRadius": 8, "borderTopRightRadius": 8, "borderBottomRightRadius": 8, "borderBottomLeftRadius": 8, "fontSize": 13 }, ".theme-dark ": { "backgroundColor": "#2f3d37", "color": "#d9f0e5" } }, "avoid-chip": { "": { "backgroundColor": "#f0deda", "color": "#8a4e44" }, ".theme-dark ": { "backgroundColor": "#49383a", "color": "#f0deda" } }, "suggest-text": { "": { "fontSize": 14, "color": "#57463a", "lineHeight": "22px" }, ".theme-dark ": { "color": "#d2c4b3" } }, "knowledge-tabs": { "": { "flexDirection": "row", "flexWrap": "wrap", "marginBottom": 10 } }, "knowledge-tab": { "": { "paddingTop": 8, "paddingRight": 12, "paddingBottom": 8, "paddingLeft": 12, "borderTopLeftRadius": 10, "borderTopRightRadius": 10, "borderBottomRightRadius": 10, "borderBottomLeftRadius": 10, "backgroundColor": "#efe6d7", "borderTopWidth": 1, "borderRightWidth": 1, "borderBottomWidth": 1, "borderLeftWidth": 1, "borderTopStyle": "solid", "borderRightStyle": "solid", "borderBottomStyle": "solid", "borderLeftStyle": "solid", "borderTopColor": "#dcc4a9", "borderRightColor": "#dcc4a9", "borderBottomColor": "#dcc4a9", "borderLeftColor": "#dcc4a9" }, ".theme-dark ": { "backgroundColor": "#353a40", "borderTopColor": "#4a525e", "borderRightColor": "#4a525e", "borderBottomColor": "#4a525e", "borderLeftColor": "#4a525e" } }, "knowledge-tab-active": { "": { "backgroundColor": "#1f6a50", "borderTopColor": "#1f6a50", "borderRightColor": "#1f6a50", "borderBottomColor": "#1f6a50", "borderLeftColor": "#1f6a50" } }, "knowledge-tab-text": { "": { "fontSize": 13, "color": "#2b1f18" }, ".theme-dark ": { "color": "#f2e9dc" } }, "knowledge-tab-text-active": { "": { "color": "#ffffff" } }, "knowledge-content": { "": { "fontSize": 14, "lineHeight": "22px", "color": "#5e4a3b", "flexGrow": 1, "flexShrink": 1, "flexBasis": "0%" }, ".theme-dark ": { "color": "#d1c3b2" } }, "knowledge-list": { "": { "marginTop": 2 } }, "knowledge-item": { "": { "flexDirection": "row", "alignItems": "flex-start", "marginBottom": 8 } }, "knowledge-index": { "": { "width": 20, "fontSize": 13, "fontWeight": "700", "color": "#2b1f18" }, ".theme-dark ": { "color": "#f2e9dc" } }, "memo-input": { "": { "width": "100%", "height": 92, "backgroundColor": "#f8f1e7", "borderTopLeftRadius": 12, "borderTopRightRadius": 12, "borderBottomRightRadius": 12, "borderBottomLeftRadius": 12, "paddingTop": 10, "paddingRight": 10, "paddingBottom": 10, "paddingLeft": 10, "boxSizing": "border-box", "fontSize": 14, "color": "#45372f", "marginBottom": 12 }, ".theme-dark ": { "backgroundColor": "#353a40", "color": "#ece2d3" } }, "history-item": { "": { "flexDirection": "row", "justifyContent": "space-between", "alignItems": "center", "backgroundColor": "#f6efe5", "borderTopLeftRadius": 10, "borderTopRightRadius": 10, "borderBottomRightRadius": 10, "borderBottomLeftRadius": 10, "paddingTop": 10, "paddingRight": 12, "paddingBottom": 10, "paddingLeft": 12, "marginBottom": 8 }, ".theme-dark ": { "backgroundColor": "#343941" } }, "history-date": { "": { "fontSize": 14, "color": "#3e2f26" }, ".theme-dark ": { "color": "#f2e7d8" } }, "history-link": { "": { "fontSize": 13, "color": "#2f6f55", "fontWeight": "600" } }, "empty-tip": { "": { "backgroundColor": "#f6efe5", "borderTopLeftRadius": 10, "borderTopRightRadius": 10, "borderBottomRightRadius": 10, "borderBottomLeftRadius": 10, "paddingTop": 12, "paddingRight": 12, "paddingBottom": 12, "paddingLeft": 12, "color": "#7a6553", "fontSize": 13 }, ".theme-dark ": { "backgroundColor": "#363c42", "color": "#d2c0ae" } } };
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["styles", [_style_0]]]);
export {
  index as default
};
