#!/bin/bash
# ArkPrism - HarmonyOS Privacy API Analyzer
#
# Usage:
#   ./run.sh                     - Run with default input/ directory
#   ./run.sh <hap_dir>           - Run with a single HAP directory

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIB_DIR="${SCRIPT_DIR}/lib"
CONFIG_DIR="${SCRIPT_DIR}/config"
INPUT_DIR="${SCRIPT_DIR}/input"
OUTPUT_DIR="${SCRIPT_DIR}/out"

CLASSPATH=""
for jar in "${LIB_DIR}"/*.jar; do
    if [ -f "$jar" ]; then
        if [ -z "$CLASSPATH" ]; then
            CLASSPATH="$jar"
        else
            CLASSPATH="${CLASSPATH}:${jar}"
        fi
    fi
done

if [ $# -gt 0 ]; then
    INPUT_DIR="$1"
fi

mkdir -p "$OUTPUT_DIR"

echo "======================================================"
echo "ArkPrism Binary Privacy Analyzer"
echo "======================================================"
echo "Input:     ${INPUT_DIR}"
echo "Output:    ${OUTPUT_DIR}"
echo "Config:    ${CONFIG_DIR}"
echo ""

java -Xms4g -Xmx8g -Xss512m \
    -cp "$CLASSPATH" \
    com.huawei.hisec.Main \
    "$INPUT_DIR" \
    "$CONFIG_DIR/privacy_apis.json" \
    "$OUTPUT_DIR" \
    "$CONFIG_DIR/profile_combinations.json" \
    "$CONFIG_DIR/native_privacy_apis.json"

echo ""
echo "Analysis complete."
